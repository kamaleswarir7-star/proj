# PocketSmart AI – Your Smart Budget & Recommendation Assistant

PocketSmart AI is a full-stack academic/demo application based on the supplied project documentation. It uses **FastAPI + Jinja2 + JavaScript + SQLite + Gemini** to provide three budget planners:

- Home Interior Budget Planner
- Party Budget Planner
- Jewelry Budget Planner with optional outfit-image analysis
- JWT authentication and saved recommendation history
- GenAI chat assistant
- Built-in fallback recommendations when Gemini is not configured or unavailable

## Important implementation note
The supplied document refers to **Gemini 1.5 Flash Pro** and also alternates between Flask and FastAPI. The implementation standardizes the backend on FastAPI, as the later milestones specify, and uses the modern `google-genai` SDK. The Gemini model is configurable through `GEMINI_MODEL`; the default in this project is `gemini-3.8-flash`. Google’s current SDK supports text and image inputs and structured/controlled generation. See the official Gemini API documentation for the current model/API options.

The marketplace integrations are intentionally implemented as **search links plus a local demo catalog**, not brittle scraping. The application never claims live inventory or live prices.

## Project structure

```text
PocketSmartAI/
├── main.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── database/
│   └── .gitkeep
├── data/
├── models/
│   ├── __init__.py
│   ├── database.py
│   └── schemas.py
├── routes/
│   ├── __init__.py
│   ├── auth.py
│   ├── recommendations.py
│   └── chat.py
├── services/
│   ├── __init__.py
│   ├── catalog.py
│   ├── recommendation_service.py
│   ├── security.py
│   └── gemini_service.py
├── templates/
│   ├── base.html
│   ├── home.html
│   ├── login.html
│   ├── register.html
│   ├── dashboard.html
│   ├── home_planner.html
│   ├── party_planner.html
│   ├── jewelry_planner.html
│   ├── history.html
│   ├── chat.html
│   └── testimonials.html
├── static/
│   ├── css/style.css
│   └── js/
│       ├── app.js
│       ├── auth.js
│       ├── planners.js
│       ├── history.js
│       └── chat.js
├── uploads/
│   └── .gitkeep
└── tests/
    └── test_app.py
```

## VS Code setup on Windows

### 1. Install Python
Use Python 3.11 or newer. Check:

```powershell
python --version
```

### 2. Open the project
Unzip the project and open the `PocketSmartAI` folder in VS Code.

### 3. Create a virtual environment

```powershell
python -m venv .venv
```

Activate it in PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt:

```cmd
.venv\Scripts\activate.bat
```

### 4. Install dependencies

```powershell
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

### 5. Configure Gemini
Copy `.env.example` to `.env`.

```text
GEMINI_API_KEY=your_real_key
GEMINI_MODEL=gemini-3.8-flash
SECRET_KEY=replace-with-a-long-random-secret
```

Do not commit `.env` or share your API key.

If you do not configure a Gemini key, the three planners still work using the built-in deterministic fallback recommendation engine. The AI chat will tell you that Gemini is not configured.

### 6. Run the application
From the folder containing `main.py`:

```powershell
python main.py
```

Or:

```powershell
python -m uvicorn main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

API documentation is available at:

```text
http://127.0.0.1:8000/docs
```

### 7. Test

```powershell
python -m pytest -q
```

## Test checklist

1. Register a new account.
2. Login.
3. Open Dashboard.
4. Generate a Home plan.
5. Generate a Party plan.
6. Generate a Jewelry plan without an image.
7. Generate a Jewelry plan with a JPG/PNG/WEBP outfit image.
8. Open History and confirm saved plans appear.
9. Open AI Chat.
10. Temporarily remove `GEMINI_API_KEY` and confirm the fallback planner still works.

## API routes

- `POST /api/register`
- `POST /api/login`
- `POST /api/logout`
- `GET /api/session-info`
- `GET /api/session-data`
- `POST /api/generate-home`
- `POST /api/generate-party`
- `POST /api/generate-jewelry`
- `GET /api/history`
- `GET /api/recommendations-details/{history_id}`
- `POST /api/chat`
- `GET /api/health`

## Security choices

Passwords are never stored as plain text. They are hashed using PBKDF2-HMAC-SHA256 with a random salt. JWT access tokens are used for API authentication. For a production deployment, use HTTPS, a strong secret stored in a secret manager, secure cookies, rate limiting, CSRF protection where applicable, and a production database.

## What is simulated

The supplied documentation asks for integrations with Amazon, Flipkart, IKEA, Swiggy, Zomato and OYO. This project uses marketplace search URLs and an internal demo catalog rather than unauthorized scraping. Exact live product availability and prices should be fetched through an approved marketplace API/affiliate program if you later obtain access.
