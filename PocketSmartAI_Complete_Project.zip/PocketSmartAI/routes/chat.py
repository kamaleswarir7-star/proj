from fastapi import APIRouter, Depends
from models.schemas import ChatRequest
from services.gemini_service import chat
from routes.auth import current_user

router=APIRouter()
@router.post("/chat")
def send_chat(data: ChatRequest, user=Depends(current_user)):
    return {"reply":chat(data.message,data.history)}
