from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse, RedirectResponse
from sqlalchemy.orm import Session
from models.database import get_db, User
from models.schemas import UserCreate, UserLogin
from services.security import hash_password, verify_password, create_access_token, decode_access_token

router=APIRouter()

def current_user(request: Request, db: Session=Depends(get_db)):
    auth=request.headers.get("Authorization", "")
    token=auth.replace("Bearer ", "", 1).strip() if auth.startswith("Bearer ") else request.cookies.get("access_token")
    if not token:
        raise HTTPException(401,"Authentication required")
    uid=decode_access_token(token)
    if not uid:
        raise HTTPException(401,"Invalid or expired token")
    user=db.get(User,uid)
    if not user:
        raise HTTPException(401,"User not found")
    return user

@router.post("/register")
def register(data: UserCreate, db: Session=Depends(get_db)):
    email=data.email.lower()
    if db.query(User).filter(User.email==email).first():
        raise HTTPException(409,"An account with this email already exists")
    user=User(name=data.name.strip(),email=email,password_hash=hash_password(data.password))
    db.add(user); db.commit(); db.refresh(user)
    token=create_access_token(user.id)
    return {"message":"Registration successful","access_token":token,"user":{"id":user.id,"name":user.name,"email":user.email}}

@router.post("/login")
def login(data: UserLogin, db: Session=Depends(get_db)):
    user=db.query(User).filter(User.email==data.email.lower()).first()
    if not user or not verify_password(data.password,user.password_hash):
        raise HTTPException(401,"Incorrect email or password")
    token=create_access_token(user.id)
    response=JSONResponse({"message":"Login successful","access_token":token,"user":{"id":user.id,"name":user.name,"email":user.email}})
    response.set_cookie("access_token",token,httponly=True,samesite="lax",max_age=86400)
    return response

@router.post("/logout")
def logout():
    response=JSONResponse({"message":"Logged out"}); response.delete_cookie("access_token"); return response

@router.get("/session-info")
def session_info(user=Depends(current_user)):
    return {"logged_in":True,"user":{"id":user.id,"name":user.name,"email":user.email}}

@router.get("/session-data")
def session_data(user=Depends(current_user), db: Session=Depends(get_db)):
    from models.database import RecommendationHistory
    count=db.query(RecommendationHistory).filter(RecommendationHistory.user_id==user.id).count()
    return {"user_id":user.id,"name":user.name,"recommendation_count":count}
