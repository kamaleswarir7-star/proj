import json
import os
from fastapi import APIRouter, Depends, File, Form, UploadFile, HTTPException
from sqlalchemy.orm import Session
from models.database import get_db, RecommendationHistory
from models.schemas import HomeRequest, PartyRequest
from services.gemini_service import generate
from routes.auth import current_user

router=APIRouter()

def save_history(db,user,planner,request_data,result):
    row=RecommendationHistory(user_id=user.id,planner=planner,request_json=json.dumps(request_data),result_json=json.dumps(result))
    db.add(row); db.commit(); db.refresh(row)
    return row

@router.post("/generate-home")
def generate_home(data: HomeRequest, user=Depends(current_user), db: Session=Depends(get_db)):
    result=generate("home",data.model_dump())
    save_history(db,user,"home",data.model_dump(),result)
    return result

@router.post("/generate-party")
def generate_party(data: PartyRequest, user=Depends(current_user), db: Session=Depends(get_db)):
    result=generate("party",data.model_dump())
    save_history(db,user,"party",data.model_dump(),result)
    return result

@router.post("/generate-jewelry")
async def generate_jewelry(
    budget: float = Form(...), occasion: str = Form(...), style: str = Form("elegant"), colors: str = Form(""), notes: str = Form(""),
    outfit_image: UploadFile | None = File(None), user=Depends(current_user), db: Session=Depends(get_db)
):
    if budget <= 0: raise HTTPException(422,"Budget must be greater than zero")
    image_bytes=None
    if outfit_image:
        if outfit_image.content_type not in {"image/jpeg","image/png","image/webp"}:
            raise HTTPException(400,"Please upload a JPG, PNG or WEBP image")
        image_bytes=await outfit_image.read()
        if len(image_bytes)>5*1024*1024: raise HTTPException(413,"Image must be 5 MB or smaller")
    data={"budget":budget,"occasion":occasion,"style":style,"colors":colors,"notes":notes,"image_uploaded":bool(image_bytes)}
    result=generate("jewelry",data,image_bytes)
    save_history(db,user,"jewelry",data,result)
    return result

@router.get("/history")
def history(user=Depends(current_user), db: Session=Depends(get_db)):
    rows=db.query(RecommendationHistory).filter(RecommendationHistory.user_id==user.id).order_by(RecommendationHistory.id.desc()).limit(50).all()
    return [{"id":r.id,"planner":r.planner,"created_at":r.created_at.isoformat() if r.created_at else "","request":json.loads(r.request_json),"result":json.loads(r.result_json)} for r in rows]

@router.get("/recommendations-details/{history_id}")
def recommendation_details(history_id:int,user=Depends(current_user),db:Session=Depends(get_db)):
    row=db.query(RecommendationHistory).filter(RecommendationHistory.id==history_id,RecommendationHistory.user_id==user.id).first()
    if not row: raise HTTPException(404,"Recommendation not found")
    return {"id":row.id,"planner":row.planner,"request":json.loads(row.request_json),"result":json.loads(row.result_json),"created_at":row.created_at.isoformat() if row.created_at else ""}
