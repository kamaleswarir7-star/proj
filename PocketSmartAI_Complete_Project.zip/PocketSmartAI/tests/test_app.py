import os
os.environ["DATABASE_URL"] = "sqlite:///./database/test_pocketsmart.db"
os.environ["SECRET_KEY"] = "test-secret-key-that-is-long-enough-123456"
os.environ["GEMINI_API_KEY"] = ""
from fastapi.testclient import TestClient
from main import app

def test_home():
    with TestClient(app) as client:
        r=client.get("/")
        assert r.status_code==200
        assert "PocketSmart" in r.text

def test_register_login_and_home_plan():
    with TestClient(app) as client:
        email="test@example.com"
        r=client.post("/api/register",json={"name":"Test User","email":email,"password":"secret123"})
        assert r.status_code in (200,409)
        token=r.json().get("access_token") if r.status_code==200 else client.post("/api/login",json={"email":email,"password":"secret123"}).json()["access_token"]
        headers={"Authorization":f"Bearer {token}"}
        r=client.post("/api/generate-home",json={"budget":20000,"room_type":"Bedroom","style":"Modern","items":["lighting","furniture"],"quantities":{}},headers=headers)
        assert r.status_code==200
        assert r.json()["planner"]=="home"

def test_health():
    with TestClient(app) as client:
        r=client.get("/api/health")
        assert r.status_code==200
        assert r.json()["status"]=="ok"
