from copy import deepcopy
from .catalog import HOME_CATALOG, PARTY_CATALOG, JEWELRY_CATALOG

def _pick(catalog, budget, categories=None, limit=6):
    categories = set(categories or [])
    items = [x for x in catalog if not categories or x["category"] in categories]
    affordable = [x for x in items if x["price"] == 0 or x["price"] <= max(budget * 0.55, 500)]
    pool = affordable or items
    return deepcopy(sorted(pool, key=lambda x: x["price"])[:limit])

def fallback_home(data):
    budget = data["budget"]
    raw_items = data.get("items") or ["lighting", "furniture", "decor"]
    picked = _pick(HOME_CATALOG, budget, raw_items, 6)
    per = budget / max(len(picked), 1)
    recs = [{"name":x["name"],"category":x["category"],"platform":x["platform"],"estimated_price":x["price"],"quantity":1,"reason":f"Fits a {data.get('style','modern')} {data.get('room_type','room')} plan and keeps spending controlled.","url":x["url"]} for x in picked]
    total = sum(x["estimated_price"] for x in recs)
    if total > budget:
        scale = budget / total
        for x in recs: x["estimated_price"] = round(x["estimated_price"] * scale, 2)
        total = round(sum(x["estimated_price"] for x in recs), 2)
    return {"planner":"home","title":"Home Interior Budget Plan","budget":budget,"estimated_total":round(total,2),"remaining_budget":round(max(budget-total,0),2),"summary":f"A starter {data.get('style','modern')} plan for your {data.get('room_type','room')} within the stated budget.","budget_breakdown":[{"category":"Furniture","amount":round(budget*.45,2),"percentage":45,"notes":"Prioritize essential pieces."},{"category":"Lighting","amount":round(budget*.25,2),"percentage":25,"notes":"Use efficient lighting."},{"category":"Decor","amount":round(budget*.20,2),"percentage":20,"notes":"Add style after essentials."},{"category":"Reserve","amount":round(budget*.10,2),"percentage":10,"notes":"Keep a buffer."}],"recommendations":recs,"tips":["Measure the room before buying furniture.","Compare dimensions and warranty before purchase.","Treat listed prices as estimates and verify the marketplace before buying."],"ai_powered":False}

def fallback_party(data):
    budget, guests = data["budget"], data["guests"]
    food = budget*.45; decor=budget*.20; venue=budget*.20; entertainment=budget*.10; reserve=budget*.05
    picks = _pick(PARTY_CATALOG,budget,None,6)
    recs=[]
    for x in picks:
        price = x["price"]
        if x["category"] == "food": price = round(food,2)
        elif x["category"] == "venue": price = round(venue,2)
        elif x["category"] == "decor": price = round(decor/2,2)
        elif x["category"] == "entertainment": price = round(entertainment,2)
        recs.append({"name":x["name"],"category":x["category"],"platform":x["platform"],"estimated_price":price,"quantity":1,"reason":f"Useful for a {data['event_type']} event with about {guests} guests.","url":x["url"]})
    return {"planner":"party","title":"Party Budget Plan","budget":budget,"estimated_total":round(budget-reserve,2),"remaining_budget":round(reserve,2),"summary":f"A balanced starting allocation for {guests} guests and a {data['event_type']} event.","budget_breakdown":[{"category":"Catering","amount":round(food,2),"percentage":45,"notes":"Main food and drinks allocation."},{"category":"Decoration","amount":round(decor,2),"percentage":20,"notes":"Theme, balloons and basic decor."},{"category":"Venue","amount":round(venue,2),"percentage":20,"notes":"Venue or space-related costs."},{"category":"Entertainment","amount":round(entertainment,2),"percentage":10,"notes":"Music or activities."},{"category":"Reserve","amount":round(reserve,2),"percentage":5,"notes":"Unexpected costs."}],"recommendations":recs,"tips":["Get a per-person catering quote before confirming.","Keep a small emergency reserve.","Confirm venue cancellation and timing policies."],"ai_powered":False}

def fallback_jewelry(data):
    budget=data["budget"]; picked=_pick(JEWELRY_CATALOG,budget,None,6)
    recs=[{"name":x["name"],"category":x["category"],"platform":x["platform"],"estimated_price":x["price"],"quantity":1,"reason":f"A {data.get('style','elegant')} option for a {data['occasion']} occasion.","url":x["url"]} for x in picked]
    return {"planner":"jewelry","title":"Jewelry Budget Plan","budget":budget,"estimated_total":round(sum(x["estimated_price"] for x in recs),2),"remaining_budget":round(max(budget-sum(x["estimated_price"] for x in recs),0),2),"summary":f"Jewelry options for a {data['occasion']} occasion, guided by your style and budget.","budget_breakdown":[{"category":"Main jewelry","amount":round(budget*.70,2),"percentage":70,"notes":"Choose one focal piece."},{"category":"Matching pieces","amount":round(budget*.20,2),"percentage":20,"notes":"Keep supporting pieces subtle."},{"category":"Reserve","amount":round(budget*.10,2),"percentage":10,"notes":"Allow room for price variation."}],"recommendations":recs,"tips":["Match metal tone to the outfit and occasion.","For a heavily detailed outfit, consider simpler jewelry.","Verify seller reviews, material and return policy before purchase."],"ai_powered":False}
