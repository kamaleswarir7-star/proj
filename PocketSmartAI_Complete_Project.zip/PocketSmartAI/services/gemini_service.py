import json
import os
import re
from typing import Any
from PIL import Image
from io import BytesIO
from .recommendation_service import fallback_home, fallback_party, fallback_jewelry

MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
_client = None

def get_client():
    global _client
    key = os.getenv("GEMINI_API_KEY", "").strip()
    if not key or key == "your_gemini_api_key_here":
        return None
    try:
        from google import genai
    except ImportError:
        return None
    if _client is None:
        _client = genai.Client(api_key=key)
    return _client

def _extract_json(text: str) -> dict[str, Any] | None:
    if not text:
        return None
    text = text.strip()
    try:
        value=json.loads(text)
        return value if isinstance(value,dict) else None
    except json.JSONDecodeError:
        match=re.search(r"\{.*\}", text, re.S)
        if match:
            try:
                value=json.loads(match.group(0))
                return value if isinstance(value,dict) else None
            except json.JSONDecodeError:
                return None
    return None

def _prompt(planner: str, data: dict) -> str:
    return f'''You are PocketSmart AI, a budget-aware lifestyle planning assistant.\nPlanner: {planner}\nUser data: {json.dumps(data, ensure_ascii=False)}\n\nReturn ONLY valid JSON with this exact top-level shape:\n{{"planner":"{planner}","title":"...","budget":0,"estimated_total":0,"remaining_budget":0,"summary":"...","budget_breakdown":[{{"category":"...","amount":0,"percentage":0,"notes":"..."}}],"recommendations":[{{"name":"...","category":"...","platform":"Amazon/Flipkart/IKEA/Swiggy/Zomato/OYO","estimated_price":0,"quantity":1,"reason":"...","url":"https://..."}}],"tips":["..."]}}\n\nRules: Never exceed the user's budget. Use realistic ESTIMATED prices, not claims of live inventory. Use marketplace SEARCH URLs when exact live product URLs are unavailable. Clearly call prices estimates. Keep 4-8 recommendations. For a jewelry image, use it only to discuss visible style/color/coordination; do not identify the person.''' 

def _normalize(result: dict, planner: str, fallback: dict) -> dict:
    # Preserve the reliable fallback if the model omitted required data.
    out = dict(fallback)
    for key in ["title","summary","tips","budget_breakdown","recommendations","estimated_total","remaining_budget"]:
        if key in result:
            out[key]=result[key]
    out["planner"]=planner
    out["budget"]=fallback["budget"]
    out["ai_powered"]=True
    try:
        out["estimated_total"]=round(float(out["estimated_total"]),2)
        out["remaining_budget"]=round(max(fallback["budget"]-out["estimated_total"],0),2)
    except (TypeError,ValueError):
        out["estimated_total"]=fallback["estimated_total"]
        out["remaining_budget"]=fallback["remaining_budget"]
    return out

def generate(planner: str, data: dict, image_bytes: bytes | None = None):
    fallback = {"home":fallback_home,"party":fallback_party,"jewelry":fallback_jewelry}[planner](data)
    client=get_client()
    if client is None:
        return fallback
    try:
        contents=[_prompt(planner,data)]
        if image_bytes:
            image=Image.open(BytesIO(image_bytes)).convert("RGB")
            contents.append(image)
        response=client.models.generate_content(model=MODEL, contents=contents)
        parsed=_extract_json(getattr(response,"text","") or "")
        return _normalize(parsed, planner, fallback) if parsed else fallback
    except Exception:
        # The application remains usable if the API is unavailable or the key/quota is invalid.
        return fallback

def chat(message: str, history: list[dict[str,str]] | None = None) -> str:
    client=get_client()
    if client is None:
        return "Gemini is not configured yet. Add GEMINI_API_KEY to your .env file. Meanwhile, you can use the Home, Party and Jewelry planners with built-in budget fallback recommendations."
    try:
        context = "\n".join(f"{m.get('role','user')}: {m.get('content','')}" for m in (history or [])[-8:])
        prompt=f"You are PocketSmart AI, a friendly budget planning assistant. Give practical, concise answers. Do not claim live prices or availability. Conversation:\n{context}\nuser: {message}"
        response=client.models.generate_content(model=MODEL, contents=prompt)
        return getattr(response,"text","") or "I couldn't generate a response right now."
    except Exception:
        return "The AI service is temporarily unavailable. Please try again or use one of the planners."

def health_check() -> dict:
    return {"configured": bool(get_client()), "model": MODEL}
