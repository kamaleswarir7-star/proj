# Demo catalog used because public marketplace scraping is unreliable and often prohibited.
# These are search links, not claims of live stock or current prices.
HOME_CATALOG = [
    {"name":"LED Ceiling Light", "category":"lighting", "platform":"Amazon", "price":1299, "url":"https://www.amazon.in/s?k=led+ceiling+light"},
    {"name":"Modern Floor Lamp", "category":"lighting", "platform":"IKEA", "price":2499, "url":"https://www.ikea.com/in/en/search/?q=floor%20lamp"},
    {"name":"Compact Study Table", "category":"furniture", "platform":"Amazon", "price":3999, "url":"https://www.amazon.in/s?k=compact+study+table"},
    {"name":"Dining Table 4 Seater", "category":"furniture", "platform":"IKEA", "price":8999, "url":"https://www.ikea.com/in/en/search/?q=dining%20table"},
    {"name":"Decorative Wall Art", "category":"decor", "platform":"Flipkart", "price":999, "url":"https://www.flipkart.com/search?q=decorative%20wall+art"},
    {"name":"Indoor Artificial Plant", "category":"decor", "platform":"Amazon", "price":699, "url":"https://www.amazon.in/s?k=artificial+indoor+plant"},
    {"name":"Ceiling Fan", "category":"appliances", "platform":"Amazon", "price":2499, "url":"https://www.amazon.in/s?k=ceiling+fan"},
    {"name":"Storage Cabinet", "category":"storage", "platform":"IKEA", "price":5999, "url":"https://www.ikea.com/in/en/search/?q=storage%20cabinet"},
]
PARTY_CATALOG = [
    {"name":"Catering Search", "category":"food", "platform":"Swiggy", "price":0, "url":"https://www.swiggy.com/search?query=catering"},
    {"name":"Restaurant Search", "category":"food", "platform":"Zomato", "price":0, "url":"https://www.zomato.com/"},
    {"name":"Party Decoration Search", "category":"decor", "platform":"Amazon", "price":799, "url":"https://www.amazon.in/s?k=party+decoration"},
    {"name":"Hotel & Stay Search", "category":"venue", "platform":"OYO", "price":0, "url":"https://www.oyorooms.com/"},
    {"name":"Balloon Decoration Kit", "category":"decor", "platform":"Flipkart", "price":599, "url":"https://www.flipkart.com/search?q=balloon+decoration+kit"},
    {"name":"Party Speaker", "category":"entertainment", "platform":"Amazon", "price":2499, "url":"https://www.amazon.in/s?k=party+speaker"},
]
JEWELRY_CATALOG = [
    {"name":"Minimal Gold-Tone Earrings", "category":"earrings", "platform":"Amazon", "price":799, "url":"https://www.amazon.in/s?k=minimal+gold+earrings"},
    {"name":"Pearl Drop Earrings", "category":"earrings", "platform":"Flipkart", "price":899, "url":"https://www.flipkart.com/search?q=pearl+drop+earrings"},
    {"name":"Layered Necklace", "category":"necklace", "platform":"Amazon", "price":1299, "url":"https://www.amazon.in/s?k=layered+necklace"},
    {"name":"Statement Necklace", "category":"necklace", "platform":"Flipkart", "price":1599, "url":"https://www.flipkart.com/search?q=statement+necklace"},
    {"name":"Classic Bracelet", "category":"bracelet", "platform":"Amazon", "price":699, "url":"https://www.amazon.in/s?k=classic+bracelet"},
    {"name":"Elegant Bangles Set", "category":"bangles", "platform":"Flipkart", "price":999, "url":"https://www.flipkart.com/search?q=elegant+bangles"},
]
