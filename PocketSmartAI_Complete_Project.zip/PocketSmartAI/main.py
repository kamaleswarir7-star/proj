import os
from contextlib import asynccontextmanager
from dotenv import load_dotenv
load_dotenv()
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from models.database import init_db
from routes.auth import router as auth_router
from routes.recommendations import router as recommendations_router
from routes.chat import router as chat_router
from services.gemini_service import health_check

os.makedirs("database",exist_ok=True); os.makedirs("uploads",exist_ok=True)

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app=FastAPI(title="PocketSmart AI",description="Budget-aware GenAI recommendation assistant",version="1.0.0",lifespan=lifespan)
app.add_middleware(CORSMiddleware,allow_origins=["http://127.0.0.1:8000","http://localhost:8000"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
app.mount("/static",StaticFiles(directory="static"),name="static")
templates=Jinja2Templates(directory="templates")

app.include_router(auth_router,prefix="/api")
app.include_router(recommendations_router,prefix="/api")
app.include_router(chat_router,prefix="/api")

@app.get("/api/health")
def health(): return {"status":"ok",**health_check()}

def page(request:Request,name:str,**context): return templates.TemplateResponse(request,name,context)

@app.get("/",response_class=HTMLResponse)
def home(request:Request): return page(request,"home.html")
@app.get("/login",response_class=HTMLResponse)
def login_page(request:Request): return page(request,"login.html")
@app.get("/register",response_class=HTMLResponse)
def register_page(request:Request): return page(request,"register.html")
@app.get("/dashboard",response_class=HTMLResponse)
def dashboard(request:Request): return page(request,"dashboard.html")
@app.get("/home-planner",response_class=HTMLResponse)
def home_planner(request:Request): return page(request,"home_planner.html")
@app.get("/party-planner",response_class=HTMLResponse)
def party_planner(request:Request): return page(request,"party_planner.html")
@app.get("/jewelry-planner",response_class=HTMLResponse)
def jewelry_planner(request:Request): return page(request,"jewelry_planner.html")
@app.get("/history",response_class=HTMLResponse)
def history_page(request:Request): return page(request,"history.html")
@app.get("/chat",response_class=HTMLResponse)
def chat_page(request:Request): return page(request,"chat.html")
@app.get("/testimonials",response_class=HTMLResponse)
def testimonials(request:Request): return page(request,"testimonials.html")

if __name__=="__main__":
    import uvicorn
    uvicorn.run("main:app",host="127.0.0.1",port=8000,reload=True)
