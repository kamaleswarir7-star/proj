from typing import List, Optional
from pydantic import BaseModel, Field, EmailStr

class UserCreate(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    email: EmailStr
    password: str = Field(min_length=6, max_length=128)

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class RecommendationItem(BaseModel):
    name: str
    category: str
    platform: str
    estimated_price: float = 0
    quantity: int = 1
    reason: str
    url: str = "#"

class BudgetBreakdown(BaseModel):
    category: str
    amount: float
    percentage: float
    notes: str = ""

class RecommendationResponse(BaseModel):
    planner: str
    title: str
    budget: float
    estimated_total: float
    remaining_budget: float
    summary: str
    budget_breakdown: List[BudgetBreakdown] = []
    recommendations: List[RecommendationItem] = []
    tips: List[str] = []
    ai_powered: bool = False

class HomeRequest(BaseModel):
    budget: float = Field(gt=0, le=100000000)
    room_type: str = Field(min_length=2, max_length=80)
    style: str = Field(default="modern", max_length=80)
    items: List[str] = []
    quantities: dict[str, int] = {}

class PartyRequest(BaseModel):
    budget: float = Field(gt=0, le=100000000)
    guests: int = Field(gt=0, le=100000)
    event_type: str = Field(min_length=2, max_length=80)
    venue: str = Field(default="home", max_length=100)
    preferences: str = Field(default="", max_length=500)

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    history: list[dict[str, str]] = []
